import { Estudiante } from "./Estudiante";
import recorrerEstudiantes from "./recorrerEstudiantes";


export const insertarEstuduante = function(estudiante:Estudiante , arregloEstudiantes:Estudiante[])
{
    arregloEstudiantes.push(estudiante);
    return arregloEstudiantes;
}   



export const actualizarEstudiante = function( indice : number, nombre : string, apellido : string, listaEstudiante : Estudiante[]){
    //instrucciones para actualizar
//el estudiante que se encuentre
//en el indice indicado en el
//parametro
}




//borrar
export const borrarEstudiante= function (indice : number, listaEstudiantes:Estudiante[]){
    
    if (indice >= 0 && indice < listaEstudiantes.length) {
      
      listaEstudiantes.splice(indice, 1);
    }
  }
