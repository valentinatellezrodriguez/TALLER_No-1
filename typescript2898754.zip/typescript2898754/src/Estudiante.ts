export type Estudiante ={

    nombre: string;
    apellido: string;
    edad?: number;
    tipoidentificacion: string;
    numeroidentificacion: number;
}