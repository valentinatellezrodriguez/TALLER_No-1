import { Estudiante } from "./Estudiante";
import recorrerEstudiantes from "./recorrerEstudiantes";

import { insertarEstuduante, actualizarEstudiante,borrarEstudiante } from "./opereciones";

//definiendo objetoa (literal) estudiante 
const estudiante1: Estudiante ={

    nombre: "michel",
    apellido: "caballero",
    edad:17 ,
    tipoidentificacion: "Ti",
    numeroidentificacion:1035286816 
}


const estudiante2: Estudiante ={

    nombre: "juan",
    apellido: "barrero",
    tipoidentificacion: "cc",
    numeroidentificacion:1026158715
}

const estudiante3: Estudiante ={

    nombre: "maria",
    apellido: "celis",
    edad:15 ,
    tipoidentificacion: "Ti",
    numeroidentificacion:1018295617
}




const estudiante4: Estudiante ={

    nombre: "adriana",
    apellido: "García",
    edad:23 ,
    tipoidentificacion: "cc",
    numeroidentificacion:1823482672
}
//crear un areglo des estdiantes 


const listaEstudiante :Estudiante []=[ estudiante1, estudiante2,estudiante3]

console.log(listaEstudiante)

//recorrer el areglo 

recorrerEstudiantes(listaEstudiante);

//operaciones con areglos

console.log("----------")
console.log("Antes de insertar")

insertarEstuduante(estudiante4, listaEstudiante)
console.log(listaEstudiante)
console.log("----------")
console.log("Despues de insertar")


console.log("----------")
console.log("Antes de borrar")
console.log(listaEstudiante)
borrarEstudiante(1, listaEstudiante)
console.log("----------")
console.log("Despues de borrar")
console.log(listaEstudiante)



