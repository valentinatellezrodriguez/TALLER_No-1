//funciones

import { Estudiante } from "./Estudiante";


//funcion declarativa

//funcion exprecion 

//funcion flecha
const  recorrerEstudiantes = (arregloEstudiantes: Estudiante[]) => {
    arregloEstudiantes.forEach(function(elemento){
        console.log(elemento);
        console.log("----------")

    });

}
export default recorrerEstudiantes;

